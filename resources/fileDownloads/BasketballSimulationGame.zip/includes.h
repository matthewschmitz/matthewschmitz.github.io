/////////////////////////////
///
/// Matthew James Schmitz
///
/// December, 2016
///
/// File name: includes.h
///
/////////////////////////////

#ifndef includes_h
#define includes_h

#include <iostream>
#include <cmath>
#include <string>
#include <cstdlib>
#include <ctime>

using namespace std;

#endif /* includes_h */
